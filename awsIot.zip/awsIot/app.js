var awsIot = require('aws-iot-device-sdk');

//
// Replace the values of '<YourUniqueClientIdentifier>' and '<YourCustomEndpoint>'
// with a unique client identifier and custom host endpoint provided in AWS IoT.
// NOTE: client identifiers must be unique within your AWS account; if a client attempts
// to connect with a client identifier which is already in use, the existing
// connection will be terminated.
//
var device = awsIot.device({
   keyPath: 'a489d2d01d-private.pem.key',
  certPath: 'a489d2d01d-certificate.pem.crt',
    caPath: 'rootCA.pem',
  clientId: 'MyBus',
      host: 'ap-southeast-1'
});

//
// Device is an instance returned by mqtt.Client(), see mqtt.js for full
// documentation.
//
device
  .on('connect', function() {
    console.log('connect');
    //device.subscribe('busPolicy');
    device.publish('MyBusPolicy', JSON.stringify({ test_data: 'Nodejs ...'}));
  });

device
  .on('message', function(topic, payload) {
    console.log('message', topic, payload.toString());
  });
