'use strict';

var mongoose = require('mongoose');

exports.handler = (event, context, callback) =>{
  mongoose.connect('mongodb://3.1.204.253/travelDb');
  console.log("Connected Succesfully");

var User = mongoose.model('travels', {
  Date: Number,
  Temp: Number,
  Humi: Number

});
console.log("Create Schema Succesfully");

var data ='';
var err ='';

User.find({},function(err,data){
  if(err){
    context.done(err);
    console.log("Error Got:",err);
    callback(null,err);
  } else {
    context.succeed(data);
    console.log("Data Got: ",data);
    callback(null,data);
  }
});

  console.log("Function Exited Succesfully");
}
