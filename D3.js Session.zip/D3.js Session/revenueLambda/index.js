
'use strict';

var mongoose = require("mongoose");

console.log('Loading function');

exports.handler = (event, context, callback) => {

        mongoose.connect("mongodb://54.255.220.89/revenueDb");

        var schema = mongoose.Schema;

        var userSchema = new schema({

            userId : String,
            stationName : String,
            doorType : String,
            timestamp : String
        });

        var userModel = mongoose.model("travels",userSchema);

        userModel.find('',function(err,userObj){

            if(err){
                context.done();
                console.log(err);
                callback(null,err);
            }

            else{
                context.succeed(userObj);
                console.log("Found :",userObj);
                callback(null, userObj);
            }

            
        });


};
